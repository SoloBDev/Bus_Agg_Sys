declare module 'react-day-picker' {
  export interface Components {
    IconLeft?: React.ComponentType;
    IconRight?: React.ComponentType;
    // Add other custom components here
  }
}